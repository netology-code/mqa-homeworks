//
//  Created by Netology.
//
import SwiftUI

@main
struct NetologyApp: App {
    var body: some Scene {
        WindowGroup {
            MasterView()
        }
    }
}
